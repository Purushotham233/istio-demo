kubectl apply -f deploy-service-v1.0.yaml --context kind-airtel-1;
kubectl apply -f deploy-service-v1.1.yaml --context kind-airtel-2;