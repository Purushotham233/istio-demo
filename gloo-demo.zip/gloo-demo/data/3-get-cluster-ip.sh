kubectl describe nodes --context kind-mgmt | grep IP;
kubectl describe nodes --context kind-airtel-1 | grep IP;
kubectl describe nodes --context kind-airtel-2 | grep IP;