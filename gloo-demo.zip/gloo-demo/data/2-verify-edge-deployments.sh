kubectl --namespace gloo-system get all --context kind-mgmt;
kubectl --namespace gloo-system get all --context kind-airtel-1;
kubectl --namespace gloo-system get all --context kind-airtel-2;